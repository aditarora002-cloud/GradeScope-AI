from __future__ import annotations
import io
import zipfile

import numpy as np
import pandas as pd
import pytest

from data_utils import (CATEGORY_OPTIONS, NUMERIC_BOUNDS, RAW_FEATURES, extract_csv_from_archive,
                        grade_category, input_defaults, load_data, profile_from_example,
                        training_features, validate_data)


def make_zip(contents: dict[str, bytes]) -> bytes:
    memory = io.BytesIO()
    with zipfile.ZipFile(memory, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for name, payload in contents.items():
            z.writestr(name, payload)
    return memory.getvalue()


def example_frame(n=60):
    rng = np.random.default_rng(99)
    values = {}
    for field in RAW_FEATURES:
        if field in NUMERIC_BOUNDS:
            low, high = NUMERIC_BOUNDS[field]
            values[field] = rng.integers(low, high+1, size=n)
        else:
            values[field] = rng.choice(list(CATEGORY_OPTIONS[field]), size=n)
    values["G3"] = rng.integers(0, 21, size=n)
    return pd.DataFrame(values)


def test_extract_direct_csv():
    contents = b'school;G3\nGP;10\n'
    container = make_zip({"student-por.csv": contents})
    assert extract_csv_from_archive(container, "por") == contents


def test_extract_csv_in_nested_zip_and_subfolder():
    contents = b'school;G3\nGP;20\n'
    inner = make_zip({"student-por.csv": contents, "student-mat.csv": b"math"})
    outer = make_zip({"student.zip": inner})
    assert extract_csv_from_archive(outer, "por") == contents
    wrapped = make_zip({"student-pack/assets/student.zip": inner})
    assert extract_csv_from_archive(wrapped, "por") == contents


def test_missing_csv_gives_clear_error():
    with pytest.raises(FileNotFoundError, match="student-mat.csv"):
        extract_csv_from_archive(make_zip({"student.zip": make_zip({"nothing.csv": b"z"})}), "mat")


def test_grade_bands_exact_boundaries():
    assert [grade_category(x) for x in [0, 9, 10, 14, 15, 20]] == [
        "Low", "Low", "Medium", "Medium", "High", "High"]
    assert grade_category([0, 9, 10, 14, 15, 20]).tolist() == [
        "Low", "Low", "Medium", "Medium", "High", "High"]


def test_input_defaults_and_training_features():
    df = example_frame()
    validate_data(df)
    early = training_features(df)
    assert len(early.columns) == 30
    assert "G1" not in early and "G2" not in early and "G3" not in early
    late = training_features(df, include_prior_grades=True)
    assert len(late.columns) == 32
    defaults = input_defaults(df, early.columns.tolist())
    for field in early:
        assert field in defaults
    demo = profile_from_example(defaults, "Needs support")
    assert demo["studytime"] == 1
    assert demo["failures"] == 2
    assert demo["absences"] == 18


def test_loading_local_csv_no_network(tmp_path):
    df = example_frame()
    df.to_csv(tmp_path / "student-por.csv", index=False, sep=";")
    loaded = load_data("por", data_dir=tmp_path)
    pd.testing.assert_frame_equal(df, loaded)


def test_missing_columns_are_rejected():
    with pytest.raises(ValueError, match="missing UCI columns"):
        validate_data(pd.DataFrame({"G3": [15]}))
