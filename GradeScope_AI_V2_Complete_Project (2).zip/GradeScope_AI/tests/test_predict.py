import json
import joblib
import numpy as np
from sklearn.ensemble import RandomForestClassifier

from data_utils import CLASSES, grade_category, input_defaults, training_features
from predict import Predictor
from train import make_preprocessor, make_selector
from test_data_utils import example_frame


class FakeModel:
    def predict(self, x, verbose=0):
        return np.repeat(np.array([[.16, .71, .13]]), len(x), axis=0)


def test_inference_reproduces_saved_feature_pipeline(tmp_path):
    df = example_frame(150)
    df["G3"] = [7, 11, 17] * 50
    X = training_features(df)
    y = grade_category(df["G3"]).map({"Low": 0, "Medium": 1, "High": 2}).to_numpy()
    prep = make_preprocessor(X.columns.tolist())
    encoded = prep.fit_transform(X)
    selector, selected = make_selector(encoded, y, 40)
    forest = RandomForestClassifier(n_estimators=10, random_state=42).fit(selected, y)
    bundle = {"preprocessor": prep, "selector": selector, "random_forest": forest,
              "features": X.columns.tolist(), "classes": CLASSES}
    joblib.dump(bundle, tmp_path / "pipeline.joblib")
    defaults = input_defaults(df, X.columns.tolist())
    (tmp_path / "metadata.json").write_text(json.dumps({"feature_columns": X.columns.tolist(),
                                                        "input_defaults": defaults}), encoding="utf-8")
    (tmp_path / "metrics.json").write_text("{}", encoding="utf-8")
    predictor = Predictor(tmp_path)
    prediction_rf = predictor.predict(defaults, "Random Forest")
    assert prediction_rf["category"] in CLASSES
    assert abs(sum(prediction_rf["probabilities"].values()) - 1) < 1e-8
    predictor._dnn = FakeModel()
    prediction_dnn = predictor.predict(defaults, "DNN")
    assert prediction_dnn["category"] == "Medium"
    assert abs(prediction_dnn["probabilities"]["Medium"] - .71) < 1e-8
