import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split

from data_utils import grade_category, training_features
from train import make_preprocessor, make_selector, report_metrics
from test_data_utils import example_frame


def test_train_only_preprocessing_and_rf():
    df = example_frame(150)
    df["G3"] = [5, 10, 18] * 50
    X = training_features(df)
    y = grade_category(df["G3"]).map({"Low": 0, "Medium": 1, "High": 2}).to_numpy()
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)
    prep = make_preprocessor(X.columns.tolist())
    xtrain = prep.fit_transform(X_train)
    xtest = prep.transform(X_test)
    selector, xtrain = make_selector(xtrain, y_train, 40)
    xtest = selector.transform(xtest)
    assert xtrain.shape[0] == 120 and xtest.shape[0] == 30
    assert 1 <= xtrain.shape[1] <= 40
    forest = RandomForestClassifier(n_estimators=10, random_state=42)
    forest.fit(xtrain, y_train)
    results = report_metrics(y_test, forest.predict(xtest), forest.predict_proba(xtest))
    assert 0 <= results["accuracy"] <= 1
    assert len(results["confusion_matrix"]) == 3
    assert len(results["classification_report"]) >= 3
