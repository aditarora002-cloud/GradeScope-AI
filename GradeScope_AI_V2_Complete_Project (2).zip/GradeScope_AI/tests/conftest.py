"""Allow tests to run with either `pytest` or `python -m pytest`."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
