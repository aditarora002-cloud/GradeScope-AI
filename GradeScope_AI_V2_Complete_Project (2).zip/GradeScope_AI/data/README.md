# Dataset directory

No data was bundled or fabricated. The application automatically downloads **official UCI Student Performance** records on first access.

For manual installation (needed if download fails), get the archive from:
https://archive.ics.uci.edu/dataset/320/student+performance

There may be an **outer ZIP containing `student.zip`**. Open both archive levels and copy these **semicolon-separated CSVs** here:

- `student-por.csv` (649 records)
- `student-mat.csv` (395 records)

GradeScope AI validates that UCI's expected columns are present. Never substitute synthetic classroom data and claim metrics came from UCI.

Source: Cortez, P. (2008). Student Performance. UCI ML Repository, https://doi.org/10.24432/C5TG7T (CC BY 4.0).
